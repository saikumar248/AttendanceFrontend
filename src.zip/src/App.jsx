import React from "react";
import Admin from "./Admin";
import SignIn from "./SignIn";
import { Routes, Route } from "react-router-dom";
import SuperAdmin from "./SuperAdmin";
import Intern from "./Intern";
// import SignUp from "./SignUp";
import SignUp from "./components/SignUp";
function App() {
  return (
    <>
      {/* <Admin/> */}
      {/* <SignIn/> */}
      <div>
        <div className="App">
          <Routes>
            <Route path="/" element={<SignIn />} />

            <Route path="/admin/*" element={<Admin />} />
            <Route path="/super/*" element={<SuperAdmin />} />
            <Route path="/intern/*" element={<Intern/>} />|
            
            <Route path="/signup" element={<SignUp/>} />

          </Routes>
        </div>
      </div>
    </>
  );
}

export default App;
