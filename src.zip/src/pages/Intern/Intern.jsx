import React from 'react'

function Intern() {
  return (
    <div>
    <center>
      <h1>Intern Panel is Coming Soon......</h1>
    </center>
  </div>
  )
}

export default Intern