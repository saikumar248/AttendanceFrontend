import React from 'react'

function SuperAdmin() {
  return (
    <div>
      <center>
        <h1>Super Admin Panel is Coming Soon.....</h1>
      </center>
    </div>
  )
}

export default SuperAdmin