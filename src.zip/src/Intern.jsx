import React from 'react'

function Intern() {
  return (
    <div>Intern</div>
  )
}

export default Intern