import React, { useState } from "react";
import { Lock, Mail, Phone, UserCircle } from "lucide-react";
import "./SignIn.css";
import axios from "axios";
import { Link } from "react-router-dom";

import { useNavigate } from "react-router-dom";
import logo from "./assets/rs.png";

function SignIn() {
  const [error, setError] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpUser, setOtpUser] = useState("");
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    mobile: "",
    otp: "",
    role: "Admin",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };
  const handleOtpRequest = async () => {
    try {
      const response = await axios.get(`http://localhost:9090/api/fetch/mobile/${formData.mobile}`);
      console.log(response.data);
  
      setFormData((prevFormData) => ({
        ...prevFormData,
        role: response.data.designation
      }));
  
      console.log("Role set in formData:", response.data.designation);
    } catch (error) {
      console.error("Error fetching Mobile:", error);
      setError("Mobile Not Found. Please Register.");
      return;
    }
    generateAndSendOtp();
    console.log("OTP sent");
  };
  

  const generateAndSendOtp = async () => {
    const phoneNumber = formData.mobile;
    const date = new Date();
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    const Otpxyz = minutes + seconds; // OTP generated using current minutes and seconds
    setOtp(Otpxyz);
    console.log(Otpxyz);

    console.log(otp);
    setOtpSent(true);

    const message = `Dear customer, use this OTP ${Otpxyz} to signup into your Quality Thought Next account. This OTP will be valid for the next 15 mins.`;
    // const message = `Dear customer, use this OTP ${Otpxyz} to complete your signup authentication for the Chat App. This OTP will be valid for the next 15 minutes.`;

    const encodedMessage = encodeURIComponent(message);

    const apiUrl = `https://login4.spearuc.com/MOBILE_APPS_API/sms_api.php?type=smsquicksend&user=qtnextotp&pass=987654&sender=QTTINF&t_id=1707170494921610008&to_mobileno=${phoneNumber}&sms_text=${encodedMessage}`;
    try {
      const response = await axios.get(apiUrl);
      console.log("API Response:", Otpxyz);
    } catch (error) {
      setError(Otpxyz);
    }
  };

  const handleOtpVerification = () => {
    console.log("Otp", otp);
    if (otp === formData.otp) {

      navigate("/admin");
    } else {
      setError("Invalid OTP");
    }
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    if (formData.role == "Admin") {
      navigate("/admin");
    } else if (formData.role == "SuperAdmin") {
      navigate("/super");
    } else {
      navigate("/intern");
    }
  };

  return (
    <div className="container">
      <div className="form-card">
        <div className="header">
          <img src={logo} alt="Company Logo" className="company-logo" />
          <h2 className="title">Welcome Back</h2>
          <p className="subtitle">Please sign in to your account</p>
        </div>
        <form onSubmit={handleSubmit} className="form">
          <div className="form-group">
            <label className="label">Mobile Number</label>
            <div className="input-wrapper">
              {/* <Phone className="input-icon" /> */}
              <input
                type="text"
                name="mobile"
                maxLength={10}
                minLength={10}
                value={formData.mobile}
                onChange={handleChange}
                className="input"
                placeholder="Enter your Mobile Number"
                required
              />
            {/* </div> */}
            {/* <label className="label">Mobile</label> */}
            {/* <div className="input-wrapper"> */}
              {/* <input type="number" className="input" name="mobile" value={formData.mobile} onChange={handleChange} required /> */}
              {
                <button
                  type="button"
                  className="otp-btn"
                  onClick={() => handleOtpRequest("mobile")}
                >
                  {otpSent ? "Resend OTP" : "Send OTP"}
                </button>
              }
            </div>
            {otpSent && (
              <div className="otp-section">
                <input
                  type="text"
                  className="input"
                  name="otp"
                  onChange={handleChange}
                  placeholder="Enter OTP"
                  required
                />
                <button
                  type="button"
                  className="otp-btn"
                  onClick={handleOtpVerification}
                >
                  Verify OTP
                </button>
              </div>
            )}
            {error && <p className="error">{error}</p>}
          </div>
        </form>
        <div className="forgot-password">
          <span className="forgot-password" onClick={() => navigate("/signup")}>
            {"Don't"} have an account?
          </span>
        </div>
      </div>
    </div>
  );
}

export default SignIn;
