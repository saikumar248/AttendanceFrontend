import React from 'react'

function SuperAdmin() {
  return (
    <div>SuperAdmin</div>
  )
}

export default SuperAdmin